╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║    🎾 TENNIS BILLING SOFTWARE - START HERE! 🎾              ║
║              COMPLETELY OFFLINE VERSION                      ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝

👋 WELCOME!

This software will help you manage your tennis lessons quickly
and easily. It runs COMPLETELY OFFLINE on your computer.

═══════════════════════════════════════════════════════════════

🚀 QUICK START (First Time - 5 Minutes)

STEP 1: Install Python (if you don't have it)
────────────────────────────────────────────
1. Go to: https://www.python.org/downloads/
2. Click "Download Python"
3. Run the installer
4. ✅ IMPORTANT: Check "Add Python to PATH"
5. Click "Install Now"

STEP 2: Install Requirements
─────────────────────────────
1. Right-click in this folder
2. Choose "Open in Terminal" or "Command Prompt here"
3. Type: pip install -r requirements.txt
4. Press Enter
5. Wait for installation (2 minutes)

STEP 3: Run the Software
─────────────────────────
1. Double-click: START_SIMPLE.bat
2. A window will open (don't close it!)
3. Wait until you see: "Running on http://127.0.0.1:5001"
4. Open your web browser (Chrome, Edge, Firefox, etc.)
5. Go to: http://localhost:5001
6. 🎉 YOU'RE IN!

═══════════════════════════════════════════════════════════════

📥 IMPORT YOUR EXISTING DATA (First Time)

1. In the software, click "📥 Import from Excel"
2. Select: 1st-31 Jan 2026.xlsx
3. Click Open
4. Wait a few seconds
5. ✅ All your 1,075 lessons are now imported!

═══════════════════════════════════════════════════════════════

✏️ DAILY USE (Every Day - 10 Seconds!)

1. Double-click: START_SIMPLE.bat
2. Open browser: http://localhost:5001
3. Click: ➕ ADD NEW LESSON (big green button)
4. Fill in:
   - Time: "4-5 pm"
   - Student Name: "John Smith"
   - Hours: 1.0
   - Amount: 100.00
5. Click: 💾 Save
6. Done! Totals update automatically!

═══════════════════════════════════════════════════════════════

📱 USE FROM YOUR PHONE (Optional)

1. Make sure phone is on SAME WiFi as computer
2. Computer must be running the software
3. Find your computer's IP address:
   - Windows: Open Command Prompt, type: ipconfig
   - Look for: IPv4 Address (e.g., 192.168.1.100)
4. On phone browser, go to: http://YOUR_IP:5001
   Example: http://192.168.1.100:5001
5. Same huge buttons, easy to use!

═══════════════════════════════════════════════════════════════

💾 BACKUP YOUR DATA

Your data is in: simple_billing.db

To backup:
1. Copy simple_billing.db to USB or cloud
   OR
2. Click "📤 Export to Excel" anytime

═══════════════════════════════════════════════════════════════

📚 NEED MORE HELP?

Read these files (in order):
1. This file (you're reading it!) ✓
2. CLIENT_PACKAGE_INSTRUCTIONS.txt (detailed guide)
3. SIMPLE_VERSION_README.md (all features explained)

═══════════════════════════════════════════════════════════════

✅ KEY FEATURES

✓ NO INTERNET NEEDED - Works completely offline
✓ HUGE TEXT & BUTTONS - Easy to see and click
✓ 10 SECOND ENTRY - Add lesson super fast
✓ AUTO TOTALS - See today's and month's revenue instantly
✓ EXCEL EXPORT - Download data anytime
✓ PHONE ACCESS - Use from your phone at the court
✓ YOUR DATA - Stays on YOUR computer only
✓ NO FEES - Yours forever!

═══════════════════════════════════════════════════════════════

❓ TROUBLESHOOTING

Problem: "Python not found"
→ Reinstall Python, check "Add to PATH"

Problem: "Module not found"
→ Run: pip install -r requirements.txt

Problem: Can't open in browser
→ Make sure START_SIMPLE.bat is running
→ Go to: http://localhost:5001

Problem: Can't access from phone
→ Phone must be on same WiFi as computer
→ Check computer's firewall settings

═══════════════════════════════════════════════════════════════

🎉 THAT'S IT!

You're ready to use your new billing system!

Remember:
- Start: Double-click START_SIMPLE.bat
- Access: http://localhost:5001
- Add lesson: Click the BIG GREEN button
- Backup: Export to Excel regularly

Enjoy! 🎾

═══════════════════════════════════════════════════════════════
