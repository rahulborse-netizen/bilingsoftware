"""
SIMPLE TENNIS BILLING - Senior Friendly Version
Easy-to-use interface for tracking tennis lessons
"""
from flask import Flask, render_template, request, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import os
from io import BytesIO

# Initialize Flask app
app = Flask(__name__)

# Configuration
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'simple_billing.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'simple-tennis-billing'

# Initialize database
db = SQLAlchemy(app)


# Simple Lesson Model
class Lesson(db.Model):
    __tablename__ = 'lessons'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, default=date.today)
    time = db.Column(db.String(50), nullable=False)
    student_name = db.Column(db.String(200), nullable=False)
    hours = db.Column(db.Float, nullable=False)
    package = db.Column(db.String(100))
    invoice_amount = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.strftime('%Y-%m-%d'),
            'time': self.time,
            'student_name': self.student_name,
            'hours': self.hours,
            'package': self.package,
            'invoice_amount': self.invoice_amount
        }


# Routes
@app.route('/')
def index():
    """Main page - Simple lesson entry"""
    today = date.today()
    
    # Get today's lessons
    today_lessons = Lesson.query.filter_by(date=today).order_by(Lesson.time).all()
    today_total = sum(lesson.invoice_amount for lesson in today_lessons)
    
    # Get this month's total
    month_start = today.replace(day=1)
    month_lessons = Lesson.query.filter(Lesson.date >= month_start).all()
    month_total = sum(lesson.invoice_amount for lesson in month_lessons)
    
    return render_template('simple_index.html', 
                         today_lessons=today_lessons,
                         today_total=today_total,
                         month_total=month_total,
                         today_date=today)


@app.route('/api/lessons', methods=['POST'])
def add_lesson():
    """Add a new lesson"""
    data = request.get_json()
    
    lesson = Lesson(
        date=datetime.strptime(data['date'], '%Y-%m-%d').date(),
        time=data['time'],
        student_name=data['student_name'],
        hours=float(data['hours']),
        package=data.get('package', ''),
        invoice_amount=float(data['invoice_amount'])
    )
    
    db.session.add(lesson)
    db.session.commit()
    
    return jsonify({'success': True, 'lesson': lesson.to_dict()})


@app.route('/api/lessons/<int:id>', methods=['DELETE'])
def delete_lesson(id):
    """Delete a lesson"""
    lesson = Lesson.query.get_or_404(id)
    db.session.delete(lesson)
    db.session.commit()
    return jsonify({'success': True})


@app.route('/api/lessons/<int:id>', methods=['PUT'])
def update_lesson(id):
    """Update a lesson"""
    lesson = Lesson.query.get_or_404(id)
    data = request.get_json()
    
    lesson.date = datetime.strptime(data['date'], '%Y-%m-%d').date()
    lesson.time = data['time']
    lesson.student_name = data['student_name']
    lesson.hours = float(data['hours'])
    lesson.package = data.get('package', '')
    lesson.invoice_amount = float(data['invoice_amount'])
    
    db.session.commit()
    return jsonify({'success': True, 'lesson': lesson.to_dict()})


@app.route('/history')
def history():
    """View all lessons history"""
    selected_date = request.args.get('date')
    
    if selected_date:
        filter_date = datetime.strptime(selected_date, '%Y-%m-%d').date()
        lessons = Lesson.query.filter_by(date=filter_date).order_by(Lesson.time).all()
    else:
        lessons = Lesson.query.order_by(Lesson.date.desc(), Lesson.time).limit(100).all()
    
    total = sum(lesson.invoice_amount for lesson in lessons)
    
    return render_template('simple_history.html', lessons=lessons, total=total, selected_date=selected_date)


@app.route('/import_excel', methods=['POST'])
def import_excel():
    """Import lessons from Excel file"""
    if 'file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'})
    
    try:
        # Read Excel file
        wb = openpyxl.load_workbook(file)
        sheet = wb.active
        
        imported_count = 0
        
        # Skip header row, start from row 2
        for row in sheet.iter_rows(min_row=2, values_only=True):
            if not row[0]:  # Skip if no date
                continue
            
            try:
                lesson_date = row[0] if isinstance(row[0], date) else datetime.strptime(str(row[0]), '%Y-%m-%d').date()
                time_str = str(row[1]) if row[1] else ''
                student_name = str(row[2]) if row[2] else 'Unknown'
                hours = float(row[3]) if row[3] else 1.0
                package = str(row[4]) if row[4] else ''
                invoice = float(row[5]) if row[5] else 0.0
                
                # Check if lesson already exists
                existing = Lesson.query.filter_by(
                    date=lesson_date,
                    time=time_str,
                    student_name=student_name
                ).first()
                
                if not existing:
                    lesson = Lesson(
                        date=lesson_date,
                        time=time_str,
                        student_name=student_name,
                        hours=hours,
                        package=package,
                        invoice_amount=invoice
                    )
                    db.session.add(lesson)
                    imported_count += 1
            except Exception as e:
                print(f"Error importing row: {e}")
                continue
        
        db.session.commit()
        return jsonify({'success': True, 'imported': imported_count})
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/export_excel')
def export_excel():
    """Export all lessons to Excel file"""
    # Get all lessons
    lessons = Lesson.query.order_by(Lesson.date, Lesson.time).all()
    
    # Create workbook
    wb = openpyxl.Workbook()
    sheet = wb.active
    sheet.title = "Tennis Lessons"
    
    # Header style
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=12)
    
    # Write headers
    headers = ['Date', 'Time', "Student's Name/Program", 'Hours', 'Package/Group', 'Invoice']
    for col, header in enumerate(headers, 1):
        cell = sheet.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')
    
    # Write data
    for row, lesson in enumerate(lessons, 2):
        sheet.cell(row=row, column=1, value=lesson.date)
        sheet.cell(row=row, column=2, value=lesson.time)
        sheet.cell(row=row, column=3, value=lesson.student_name)
        sheet.cell(row=row, column=4, value=lesson.hours)
        sheet.cell(row=row, column=5, value=lesson.package)
        sheet.cell(row=row, column=6, value=lesson.invoice_amount)
    
    # Adjust column widths
    sheet.column_dimensions['A'].width = 12
    sheet.column_dimensions['B'].width = 15
    sheet.column_dimensions['C'].width = 30
    sheet.column_dimensions['D'].width = 8
    sheet.column_dimensions['E'].width = 15
    sheet.column_dimensions['F'].width = 10
    
    # Save to BytesIO
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    
    filename = f"Tennis_Lessons_{datetime.now().strftime('%Y%m%d')}.xlsx"
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=filename
    )


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    # Run on all interfaces to be accessible from other devices
    app.run(host='0.0.0.0', port=5001, debug=True)
